#!/system/bin/sh


chattr -i /data/system/mcd/df

pm pm install-existing --user 0 com.miui.daemon

pm clear com.xiaomi.joyose
#清除数据joyose
pm clear com.xiaomi.powerchecker
#清除数据耗电检测
am start --windowingMode 5 -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
sleep 2s
am force-stop com.xiaomi.joyose

rm -f /data/vendor/thermal/config/*