#!/system/bin/sh
MODPATH=/data/adb/modules/JE/
#开机休眠
until [ $(getprop sys.boot_completed) == 1 ]; do
sleep 1
done



         
         pm uninstall -k --user 0 com.miui.analytics
         pm uninstall -k --user 0 com.miui.daemon
         pm clear com.miui.daemon
         pm install-existing --user 0 com.xiaomi.joyose
         pm clear com.xiaomi.powerchecker
         pm clear com.xiaomi.joyose
         chattr -i /data/system/mcd/df
         rm -f /data/system/mcd/df
         echo '' > /data/system/mcd/df
         chattr +i /data/system/mcd/df
         am start --windowingMode 5 -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
         cmd activity broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
sleep 3s
         am force-stop com.xiaomi.joyose

         device_config put activity_manager max_cached_processes 2147483647
         device_config put activity_manager max_phantom_processes 2147483647

#清除数据休眠
sleep 10s

#清除数据joyose

        rm -f /data/vendor/thermal/config/*
        sleep 2s
        cp $MODPATH/data/vendor/thermal/config/* /data/vendor/thermal/config/
        chmod 771 /data/vendor/thermal/config/*

