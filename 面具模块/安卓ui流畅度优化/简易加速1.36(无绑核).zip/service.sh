MODDIR=${0%/*}
wait_() {
while [ "$(getprop sys.boot_completed)" != "1" ]; do
sleep 1
done
local file="/sdcard/Android/.PT"
true >"$file"
while [ ! -f "$file" ]; do
true >"$file"
sleep 1
done
rm "$file"
}
chmod 755 $MODDIR/Easyboost
wait_
/system/bin/sh $MODDIR/Easyboost