set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/Easyboost 0 0 0755 0755
echo 群号：790355353
